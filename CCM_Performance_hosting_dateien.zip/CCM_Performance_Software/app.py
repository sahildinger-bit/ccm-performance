import os
import io
import sqlite3
from datetime import datetime, date, timedelta
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, g, send_file, jsonify
import qrcode
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
try:
    from pypdf import PdfReader, PdfWriter
except Exception:
    from PyPDF2 import PdfReader, PdfWriter

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "ccm_performance_software.db")
LOGO_PATH = os.path.join(BASE_DIR, "static", "logo.png")

app = Flask(__name__)
app.secret_key = "ccm-ultra-secret-2026"

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def sync_default_vehicle_prices():
    db = sqlite3.connect(DB_PATH)
    cur = db.cursor()
    updates = [
        ("AC CM 6660", 500, 900, 1000, 4500, 2000, 3000),
        ("AC CM 6606", 500, 900, 1000, 4500, 2000, 3000),
        ("AC CM 3330", 250, 600, 700, 2699, 1000, 2000),
        ("AC CM 8808", 300, 800, 900, 4000, 2000, 3000),
        ("AC CM 8080", 95, 280, 300, 1500, 500, 1000),
        ("AC CM 8081", 110, 299, 319, 1800, 500, 1000),
    ]
    for plate, daily_price, four_day_price, weekend_price, monthly_price, deposit_short, deposit_month in updates:
        cur.execute("""
            UPDATE vehicles
            SET daily_price=?, four_day_price=?, weekend_price=?, monthly_price=?, deposit_short=?, deposit_month=?
            WHERE plate=?
        """, (daily_price, four_day_price, weekend_price, monthly_price, deposit_short, deposit_month, plate))
    db.commit()
    db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    cur = db.cursor()

    cur.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS vehicles(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        plate TEXT NOT NULL,
        daily_price REAL NOT NULL,
        four_day_price REAL NOT NULL,
        weekend_price REAL NOT NULL,
        monthly_price REAL NOT NULL,
        deposit_short REAL NOT NULL,
        deposit_month REAL NOT NULL,
        km_day INTEGER NOT NULL DEFAULT 150,
        km_offer INTEGER NOT NULL DEFAULT 350,
        km_month INTEGER NOT NULL DEFAULT 1000,
        status TEXT NOT NULL DEFAULT 'Frei',
        image_link TEXT,
        color_tag TEXT DEFAULT '',
        note TEXT DEFAULT ''
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS customers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        birth_date TEXT,
        license_no TEXT,
        license_checked TEXT DEFAULT 'Nein',
        license_link TEXT,
        id_link TEXT,
        note TEXT
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS bookings(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicle_id INTEGER NOT NULL,
        customer_id INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        pickup_time TEXT,
        end_date TEXT NOT NULL,
        return_time TEXT,
        special_price REAL,
        special_reason TEXT,
        extra_km REAL DEFAULT 0,
        deposit_status TEXT DEFAULT 'nicht bezahlt',
        pickup_km REAL,
        return_km REAL,
        pickup_fuel TEXT,
        return_fuel TEXT,
        note TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(vehicle_id) REFERENCES vehicles(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS reservations(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        vehicle_name TEXT,
        start_date TEXT,
        end_date TEXT,
        pickup_time TEXT,
        return_time TEXT,
        status TEXT DEFAULT 'offen',
        source TEXT DEFAULT 'Telefon / WhatsApp',
        note TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS damages(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        report_date TEXT NOT NULL,
        vehicle_id INTEGER NOT NULL,
        customer_id INTEGER,
        description TEXT NOT NULL,
        location_on_vehicle TEXT,
        cost REAL DEFAULT 0,
        file_link TEXT,
        status TEXT DEFAULT 'offen',
        note TEXT,
        FOREIGN KEY(vehicle_id) REFERENCES vehicles(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    )""")

    cur.execute("""CREATE TABLE IF NOT EXISTS settings(
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )""")

    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        cur.execute("INSERT INTO users(username,password) VALUES (?,?)", ("admin", "ccm123"))

    cur.execute("SELECT COUNT(*) FROM vehicles")
    if cur.fetchone()[0] == 0:
        vehicles = [
            ("Audi RS6 Performance (blue)", "AC CM 6660", 500, 900, 1000, 4500, 2000, 3000, 150, 350, 1000, "Frei", "", "blue", ""),
            ("Audi RS6 Performance (black)", "AC CM 6606", 500, 900, 1000, 4500, 2000, 3000, 150, 350, 1000, "Frei", "", "black", ""),
            ("Audi RS3 Sportback", "AC CM 3330", 250, 600, 700, 2699, 1000, 2000, 150, 350, 1000, "Frei", "", "", ""),
            ("Audi RSQ8 (blue)", "AC CM 8808", 300, 800, 900, 4000, 2000, 3000, 150, 350, 1000, "Frei", "", "blue", ""),
            ("VW GTI", "AC CM 8080", 95, 280, 300, 1500, 500, 1000, 150, 350, 1000, "Frei", "", "", ""),
            ("VW GTI Clubsport", "AC CM 8081", 110, 299, 319, 1800, 500, 1000, 150, 350, 1000, "Frei", "", "", ""),
        ]
        cur.executemany("""
            INSERT INTO vehicles(
                name, plate, daily_price, four_day_price, weekend_price, monthly_price,
                deposit_short, deposit_month, km_day, km_offer, km_month, status, image_link, color_tag, note
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, vehicles)

    defaults = {
        "company_name": "CCM Performance – Luxury Rental Cars",
        "company_address": "Strangenhäuschen 19A, 52070 Aachen",
        "company_phone": "0174 6767616",
        "base_contract_url": "https://ccm-vertrag.de",
        "processing_fee": "25",
        "self_participation": "2500",
        "minimum_age": "21",
        "min_license_years": "2",
        "allowed_area": "vereinbarten Gebiet"
    }
    for k, v in defaults.items():
        cur.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))

    db.commit()
    db.close()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def parse_date(s):
    return datetime.strptime(s, "%Y-%m-%d").date()

def contract_no(booking_id):
    return f"CCM-2026-{booking_id:03d}"

def invoice_no(booking_id):
    return f"CCM-RG-2026-{booking_id:03d}"

def get_setting(key, default=""):
    row = get_db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default

def wrap_text(text, max_chars=90):
    words = str(text).split()
    lines = []
    line = []
    for word in words:
        test = " ".join(line + [word])
        if len(test) > max_chars and line:
            lines.append(" ".join(line))
            line = [word]
        else:
            line.append(word)
    if line:
        lines.append(" ".join(line))
    return lines

def draw_wrapped_lines(c, lines, x, y, width_chars=90, font="Helvetica", size=9, leading=12):
    c.setFont(font, size)
    for entry in lines:
        sublines = wrap_text(entry, width_chars) if isinstance(entry, str) else [str(entry)]
        for sub in sublines:
            c.drawString(x, y, sub)
            y -= leading
    return y

def calculate_price(row):
    start = parse_date(row["start_date"])
    end = parse_date(row["end_date"])
    days = (end - start).days + 1
    weekday = start.weekday()

    if row["special_price"] not in (None, "", 0):
        tariff = "Sonderpreis"
        rent = float(row["special_price"])
        deposit = float(row["deposit_short"])
        km = int(row["km_offer"])
    elif days >= 28:
        tariff = "Monat"
        rent = float(row["monthly_price"])
        deposit = float(row["deposit_month"])
        km = int(row["km_month"])
    elif days == 4:
        tariff = "4 Tage"
        rent = float(row["four_day_price"])
        deposit = float(row["deposit_short"])
        km = int(row["km_offer"])
    elif weekday == 4 and days == 3:
        tariff = "Fr-So"
        rent = float(row["weekend_price"])
        deposit = float(row["deposit_short"])
        km = int(row["km_offer"])
    else:
        tariff = "Tag"
        rent = float(row["daily_price"]) * days
        deposit = float(row["deposit_short"])
        km = int(row["km_day"]) * days

    extra = float(row["extra_km"] or 0)
    extra_price = extra * 1.0
    total = rent + extra_price
    profit = total * 0.85
    return {
        "days": days,
        "tariff": tariff,
        "rent": round(rent, 2),
        "deposit": round(deposit, 2),
        "extra_price": round(extra_price, 2),
        "total": round(total, 2),
        "profit": round(profit, 2),
        "included_km": km
    }

def fetch_bookings_full():
    return get_db().execute("""
        SELECT b.*,
               v.name AS vehicle_name, v.plate, v.image_link, v.color_tag, v.status AS vehicle_status,
               v.daily_price, v.four_day_price, v.weekend_price, v.monthly_price,
               v.deposit_short, v.deposit_month, v.km_day, v.km_offer, v.km_month,
               c.first_name || ' ' || c.last_name AS customer_name,
               c.phone, c.email, c.address, c.license_no, c.license_checked
        FROM bookings b
        JOIN vehicles v ON v.id=b.vehicle_id
        JOIN customers c ON c.id=b.customer_id
        ORDER BY b.start_date DESC, b.id DESC
    """).fetchall()

def monthly_revenue(bookings):
    vals = {m: 0 for m in range(1, 13)}
    for row in bookings:
        calc = calculate_price(row)
        vals[parse_date(row["start_date"]).month] += calc["total"]
    return vals

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = request.form["username"].strip()
        p = request.form["password"].strip()
        row = get_db().execute("SELECT * FROM users WHERE username=? AND password=?", (u, p)).fetchone()
        if row:
            session["user_id"] = row["id"]
            session["username"] = row["username"]
            return redirect(url_for("dashboard"))
        flash("Login falsch.")
    return render_template("login.html", title="Login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    db = get_db()
    totals = {
        "vehicles": db.execute("SELECT COUNT(*) c FROM vehicles").fetchone()["c"],
        "customers": db.execute("SELECT COUNT(*) c FROM customers").fetchone()["c"],
        "bookings": db.execute("SELECT COUNT(*) c FROM bookings").fetchone()["c"],
        "damages": db.execute("SELECT COUNT(*) c FROM damages").fetchone()["c"],
    }
    bookings = fetch_bookings_full()
    revenue = 0
    profit = 0
    recent = []
    for row in bookings[:8]:
        calc = calculate_price(row)
        revenue += calc["total"]
        profit += calc["profit"]
        recent.append({"row": row, "calc": calc, "contract_no": contract_no(row["id"])})

    vehicle_status = db.execute("SELECT * FROM vehicles ORDER BY name").fetchall()
    month_vals = monthly_revenue(bookings)
    max_val = max(month_vals.values()) if month_vals else 0
    month_data = []
    month_names = ["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"]
    for i in range(1,13):
        v = month_vals[i]
        pct = 0 if max_val == 0 else max(6, int(v / max_val * 100))
        month_data.append({"label": month_names[i-1], "value": round(v,2), "pct": pct})

    util = []
    for v in vehicle_status:
        count = db.execute("SELECT COUNT(*) c FROM bookings WHERE vehicle_id=?", (v["id"],)).fetchone()["c"]
        util.append({"name": v["name"], "count": count})

    return render_template("dashboard.html", title="Dashboard", totals=totals, revenue=revenue, profit=profit, recent=recent, vehicle_status=vehicle_status, month_data=month_data, util=util)

@app.route("/vehicles", methods=["GET", "POST"])
@login_required
def vehicles():
    db = get_db()
    if request.method == "POST":
        db.execute("""
            INSERT INTO vehicles(
                name, plate, daily_price, four_day_price, weekend_price, monthly_price,
                deposit_short, deposit_month, km_day, km_offer, km_month, status, image_link, color_tag, note
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            request.form["name"], request.form["plate"], request.form["daily_price"],
            request.form["four_day_price"], request.form["weekend_price"], request.form["monthly_price"],
            request.form["deposit_short"], request.form["deposit_month"], request.form.get("km_day", 150),
            request.form.get("km_offer", 350), request.form.get("km_month", 1000),
            request.form.get("status", "Frei"), request.form.get("image_link", ""), request.form.get("color_tag", ""), request.form.get("note", "")
        ))
        db.commit()
        flash("Fahrzeug gespeichert.")
        return redirect(url_for("vehicles"))
    items = db.execute("SELECT * FROM vehicles ORDER BY name").fetchall()
    return render_template("vehicles.html", title="Fahrzeuge", items=items)

@app.route("/customers", methods=["GET", "POST"])
@login_required
def customers():
    db = get_db()
    if request.method == "POST":
        db.execute("""
            INSERT INTO customers(
                first_name,last_name,phone,email,address,birth_date,license_no,
                license_checked,license_link,id_link,note
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (
            request.form["first_name"], request.form["last_name"], request.form.get("phone", ""),
            request.form.get("email", ""), request.form.get("address", ""), request.form.get("birth_date", ""),
            request.form.get("license_no", ""), request.form.get("license_checked", "Nein"),
            request.form.get("license_link", ""), request.form.get("id_link", ""), request.form.get("note", "")
        ))
        db.commit()
        flash("Kunde gespeichert.")
        return redirect(url_for("customers"))

    q = request.args.get("q", "").strip()
    if q:
        like = f"%{q}%"
        items = db.execute("""
            SELECT * FROM customers
            WHERE first_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR email LIKE ? OR license_no LIKE ?
            ORDER BY last_name, first_name
        """, (like, like, like, like, like)).fetchall()
    else:
        items = db.execute("SELECT * FROM customers ORDER BY last_name, first_name").fetchall()

    return render_template("customers.html", title="Kunden", items=items, edit_item=None, q=q)


@app.route("/customers/edit/<int:customer_id>", methods=["GET", "POST"])
@login_required
def customer_edit(customer_id):
    db = get_db()
    item = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    if not item:
        flash("Kunde nicht gefunden.")
        return redirect(url_for("customers"))

    if request.method == "POST":
        db.execute("""
            UPDATE customers
            SET first_name=?, last_name=?, phone=?, email=?, address=?, birth_date=?,
                license_no=?, license_checked=?, license_link=?, id_link=?, note=?
            WHERE id=?
        """, (
            request.form["first_name"], request.form["last_name"], request.form.get("phone", ""),
            request.form.get("email", ""), request.form.get("address", ""), request.form.get("birth_date", ""),
            request.form.get("license_no", ""), request.form.get("license_checked", "Nein"),
            request.form.get("license_link", ""), request.form.get("id_link", ""), request.form.get("note", ""),
            customer_id
        ))
        db.commit()
        flash("Kunde aktualisiert.")
        return redirect(url_for("customers"))

    items = db.execute("SELECT * FROM customers ORDER BY last_name, first_name").fetchall()
    return render_template("customers.html", title="Kunden", items=items, edit_item=item, q="")

@app.route("/customers/delete/<int:customer_id>", methods=["POST"])
@login_required
def customer_delete(customer_id):
    db = get_db()
    item = db.execute("SELECT * FROM customers WHERE id=?", (customer_id,)).fetchone()
    if not item:
        flash("Kunde nicht gefunden.")
        return redirect(url_for("customers"))

    booking_count = db.execute("SELECT COUNT(*) c FROM bookings WHERE customer_id=?", (customer_id,)).fetchone()["c"]
    damage_count = db.execute("SELECT COUNT(*) c FROM damages WHERE customer_id=?", (customer_id,)).fetchone()["c"]

    if booking_count > 0 or damage_count > 0:
        flash("Kunde kann nicht gelöscht werden, solange Buchungen oder Schäden verknüpft sind.")
        return redirect(url_for("customers"))

    db.execute("DELETE FROM customers WHERE id=?", (customer_id,))
    db.commit()
    flash("Kunde gelöscht.")
    return redirect(url_for("customers"))

@app.route("/bookings", methods=["GET", "POST"])
@login_required
def bookings():
    db = get_db()
    if request.method == "POST":
        db.execute("""
            INSERT INTO bookings(
                vehicle_id,customer_id,start_date,pickup_time,end_date,return_time,
                special_price,special_reason,extra_km,deposit_status,pickup_km,return_km,pickup_fuel,return_fuel,note
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            request.form["vehicle_id"], request.form["customer_id"], request.form["start_date"],
            request.form.get("pickup_time", ""), request.form["end_date"], request.form.get("return_time", ""),
            request.form.get("special_price") or None, request.form.get("special_reason", ""),
            request.form.get("extra_km") or 0, request.form.get("deposit_status", "nicht bezahlt"),
            request.form.get("pickup_km") or None, request.form.get("return_km") or None,
            request.form.get("pickup_fuel", ""), request.form.get("return_fuel", ""), request.form.get("note", "")
        ))
        db.commit()
        flash("Buchung gespeichert.")
        return redirect(url_for("bookings"))

    vehicles = db.execute("SELECT id, name FROM vehicles ORDER BY name").fetchall()
    customers = db.execute("SELECT id, first_name || ' ' || last_name AS full_name FROM customers ORDER BY last_name, first_name").fetchall()
    rows = fetch_bookings_full()
    items = []
    for row in rows:
        calc = calculate_price(row)
        items.append({"row": row, "calc": calc, "contract_no": contract_no(row["id"]), "invoice_no": invoice_no(row["id"])})
    return render_template("bookings.html", title="Buchungen", vehicles=vehicles, customers=customers, items=items, edit_item=None)

@app.route("/bookings/edit/<int:booking_id>", methods=["GET", "POST"])
@login_required
def booking_edit(booking_id):
    db = get_db()
    item = db.execute("SELECT * FROM bookings WHERE id=?", (booking_id,)).fetchone()
    if not item:
        flash("Buchung nicht gefunden.")
        return redirect(url_for("bookings"))

    if request.method == "POST":
        db.execute("""
            UPDATE bookings
            SET vehicle_id=?, customer_id=?, start_date=?, pickup_time=?, end_date=?, return_time=?,
                special_price=?, special_reason=?, extra_km=?, deposit_status=?, pickup_km=?, return_km=?,
                pickup_fuel=?, return_fuel=?, note=?
            WHERE id=?
        """, (
            request.form["vehicle_id"], request.form["customer_id"], request.form["start_date"],
            request.form.get("pickup_time", ""), request.form["end_date"], request.form.get("return_time", ""),
            request.form.get("special_price") or None, request.form.get("special_reason", ""),
            request.form.get("extra_km") or 0, request.form.get("deposit_status", "nicht bezahlt"),
            request.form.get("pickup_km") or None, request.form.get("return_km") or None,
            request.form.get("pickup_fuel", ""), request.form.get("return_fuel", ""), request.form.get("note", ""),
            booking_id
        ))
        db.commit()
        flash("Buchung aktualisiert.")
        return redirect(url_for("bookings"))

    vehicles = db.execute("SELECT id, name FROM vehicles ORDER BY name").fetchall()
    customers = db.execute("SELECT id, first_name || ' ' || last_name AS full_name FROM customers ORDER BY last_name, first_name").fetchall()
    rows = fetch_bookings_full()
    items = []
    for row in rows:
        calc = calculate_price(row)
        items.append({"row": row, "calc": calc, "contract_no": contract_no(row["id"]), "invoice_no": invoice_no(row["id"])})
    return render_template("bookings.html", title="Buchungen", vehicles=vehicles, customers=customers, items=items, edit_item=item)

@app.route("/bookings/delete/<int:booking_id>", methods=["POST"])
@login_required
def booking_delete(booking_id):
    db = get_db()
    db.execute("DELETE FROM bookings WHERE id=?", (booking_id,))
    db.commit()
    flash("Buchung gelöscht.")
    return redirect(url_for("bookings"))

@app.route("/calendar")
@login_required
def calendar():
    db = get_db()
    vehicles = db.execute("SELECT id, name FROM vehicles ORDER BY name").fetchall()
    bookings = fetch_bookings_full()

    start = date(2026, 1, 1)
    end = date(2026, 12, 31)
    data = []
    d = start
    while d <= end:
        row = {"date": d, "items": []}
        for v in vehicles:
            booking_found = None
            for b in bookings:
                if b["vehicle_id"] == v["id"]:
                    b_start = parse_date(b["start_date"])
                    b_end = parse_date(b["end_date"])
                    if b_start <= d <= b_end:
                        booking_found = b
                        break
            row["items"].append({"vehicle": v, "booking": booking_found})
        data.append(row)
        d += timedelta(days=1)

    return render_template("calendar.html", title="Kalender", vehicles=vehicles, data=data)


@app.route("/contracts")
@login_required
def contracts():
    items = []
    for row in fetch_bookings_full():
        calc = calculate_price(row)
        items.append({"row": row, "calc": calc, "contract_no": contract_no(row["id"]), "invoice_no": invoice_no(row["id"])})
    return render_template("contracts.html", title="Verträge", items=items)


@app.route("/reservations", methods=["GET", "POST"])
@login_required
def reservations():
    db = get_db()
    if request.method == "POST":
        db.execute("""
            INSERT INTO reservations(
                customer_name, phone, email, vehicle_name, start_date, end_date,
                pickup_time, return_time, status, source, note
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (
            request.form["customer_name"],
            request.form.get("phone", ""),
            request.form.get("email", ""),
            request.form.get("vehicle_name", ""),
            request.form.get("start_date", ""),
            request.form.get("end_date", ""),
            request.form.get("pickup_time", ""),
            request.form.get("return_time", ""),
            request.form.get("status", "offen"),
            request.form.get("source", "Telefon / WhatsApp"),
            request.form.get("note", "")
        ))
        db.commit()
        flash("Reservierung gespeichert.")
        return redirect(url_for("reservations"))

    q = request.args.get("q", "").strip()
    status_filter = request.args.get("status", "").strip()
    sql = """
        SELECT * FROM reservations
        WHERE 1=1
    """
    params = []
    if q:
        like = f"%{q}%"
        sql += " AND (customer_name LIKE ? OR phone LIKE ? OR email LIKE ? OR vehicle_name LIKE ? OR note LIKE ?)"
        params += [like, like, like, like, like]
    if status_filter:
        sql += " AND status = ?"
        params.append(status_filter)
    sql += """
        ORDER BY
            CASE status
                WHEN 'offen' THEN 1
                WHEN 'bestätigt' THEN 2
                WHEN 'erledigt' THEN 3
                WHEN 'storniert' THEN 4
                ELSE 5
            END,
            start_date ASC,
            id DESC
    """
    items = db.execute(sql, params).fetchall()
    vehicles = db.execute("SELECT name FROM vehicles ORDER BY name").fetchall()
    return render_template("reservations.html", title="Reservierungen", items=items, vehicles=vehicles, q=q, status_filter=status_filter)



@app.route("/reservations/calendar")
@login_required
def reservations_calendar():
    db = get_db()
    rows = db.execute("""
        SELECT * FROM reservations
        ORDER BY start_date ASC, id ASC
    """).fetchall()

    vehicles = [r["name"] for r in db.execute("SELECT name FROM vehicles ORDER BY name").fetchall()]

    # monthly calendar from current month start to 90 days ahead
    from datetime import date, timedelta
    start = date.today().replace(day=1)
    end = start + timedelta(days=90)

    data = []
    d = start
    while d <= end:
        day_items = []
        for vehicle_name in vehicles:
            booking_found = None
            for r in rows:
                if (r["vehicle_name"] or "") == vehicle_name and r["start_date"] and r["end_date"]:
                    try:
                        rs = parse_date(r["start_date"])
                        re_ = parse_date(r["end_date"])
                    except Exception:
                        continue
                    if rs <= d <= re_:
                        booking_found = r
                        break
            day_items.append({"vehicle": vehicle_name, "reservation": booking_found})
        data.append({"date": d, "items": day_items})

        d += timedelta(days=1)

    return render_template("reservations_calendar.html", title="Reservierungskalender", data=data, vehicles=vehicles)

@app.route("/reservations/update/<int:item_id>", methods=["POST"])
@login_required
def reservation_update(item_id):
    db = get_db()
    db.execute("""
        UPDATE reservations
        SET status=?, note=?
        WHERE id=?
    """, (
        request.form.get("status", "offen"),
        request.form.get("note", ""),
        item_id
    ))
    db.commit()
    flash("Reservierung aktualisiert.")
    return redirect(url_for("reservations"))

@app.route("/reservations/delete/<int:item_id>", methods=["POST"])
@login_required
def reservation_delete(item_id):
    db = get_db()
    db.execute("DELETE FROM reservations WHERE id=?", (item_id,))
    db.commit()
    flash("Reservierung gelöscht.")
    return redirect(url_for("reservations"))


@app.route("/reservations/to-booking/<int:item_id>", methods=["POST"])
@login_required
def reservation_to_booking(item_id):
    db = get_db()
    r = db.execute("SELECT * FROM reservations WHERE id=?", (item_id,)).fetchone()
    if not r:
        flash("Reservierung nicht gefunden.")
        return redirect(url_for("reservations"))

    customer_id = None
    if r["customer_name"]:
        parts = str(r["customer_name"]).strip().split(" ", 1)
        first_name = parts[0]
        last_name = parts[1] if len(parts) > 1 else ""
        existing = db.execute(
            "SELECT id FROM customers WHERE first_name=? AND last_name=? ORDER BY id DESC LIMIT 1",
            (first_name, last_name)
        ).fetchone()
        if existing:
            customer_id = existing["id"]
        else:
            db.execute("""
                INSERT INTO customers(first_name,last_name,phone,email,address,birth_date,license_no,license_checked,license_link,id_link,note)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, (first_name, last_name, r["phone"] or "", r["email"] or "", "", "", "", "Nein", "", "", "Automatisch aus Reservierung angelegt"))
            db.commit()
            customer_id = db.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    vehicle_id = None
    if r["vehicle_name"]:
        v = db.execute("SELECT id FROM vehicles WHERE name=? LIMIT 1", (r["vehicle_name"],)).fetchone()
        if v:
            vehicle_id = v["id"]

    if not customer_id or not vehicle_id or not r["start_date"] or not r["end_date"]:
        flash("Reservierung konnte nicht umgewandelt werden. Bitte Kunde, Fahrzeug und Datum prüfen.")
        return redirect(url_for("reservations"))

    db.execute("""
        INSERT INTO bookings(
            vehicle_id, customer_id, start_date, pickup_time, end_date, return_time,
            special_price, special_reason, extra_km, deposit_status, pickup_km, return_km, pickup_fuel, return_fuel, note
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        vehicle_id, customer_id, r["start_date"], r["pickup_time"] or "", r["end_date"], r["return_time"] or "",
        None, "Aus Reservierung", 0, "nicht bezahlt", None, None, "", "", r["note"] or ""
    ))
    db.execute("UPDATE reservations SET status='bestätigt' WHERE id=?", (item_id,))
    db.commit()
    flash("Reservierung wurde in Buchung umgewandelt.")
    return redirect(url_for("bookings"))

@app.route("/damages", methods=["GET", "POST"])
@login_required
def damages():
    db = get_db()
    if request.method == "POST":
        db.execute("""
            INSERT INTO damages(
                report_date, vehicle_id, customer_id, description, location_on_vehicle,
                cost, file_link, status, note
            ) VALUES (?,?,?,?,?,?,?,?,?)
        """, (
            request.form["report_date"], request.form["vehicle_id"], request.form.get("customer_id") or None,
            request.form["description"], request.form.get("location_on_vehicle", ""),
            request.form.get("cost") or 0, request.form.get("file_link", ""),
            request.form.get("status", "offen"), request.form.get("note", "")
        ))
        db.commit()
        flash("Schaden gespeichert.")
        return redirect(url_for("damages"))

    vehicles = db.execute("SELECT id, name FROM vehicles ORDER BY name").fetchall()
    customers = db.execute("SELECT id, first_name || ' ' || last_name AS full_name FROM customers ORDER BY last_name, first_name").fetchall()
    items = db.execute("""
        SELECT d.*, v.name AS vehicle_name,
               COALESCE(c.first_name || ' ' || c.last_name, '') AS customer_name
        FROM damages d
        JOIN vehicles v ON v.id=d.vehicle_id
        LEFT JOIN customers c ON c.id=d.customer_id
        ORDER BY d.report_date DESC
    """).fetchall()
    return render_template("damages.html", title="Schäden", vehicles=vehicles, customers=customers, items=items)

@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings_view():
    db = get_db()
    if request.method == "POST":
        for key in ["company_name", "company_address", "company_phone", "base_contract_url", "processing_fee", "self_participation", "minimum_age", "min_license_years", "allowed_area"]:
            db.execute("INSERT OR REPLACE INTO settings(key, value) VALUES (?,?)", (key, request.form.get(key, "")))
        db.commit()
        flash("Einstellungen gespeichert.")
        return redirect(url_for("settings_view"))

    rows = db.execute("SELECT * FROM settings").fetchall()
    data = {r["key"]: r["value"] for r in rows}
    return render_template("settings.html", title="Einstellungen", data=data)

def pdf_header(c, number):
    w, h = A4
    if os.path.exists(LOGO_PATH):
        try:
            c.drawImage(ImageReader(LOGO_PATH), 38, h - 95, width=170, height=60, preserveAspectRatio=True, mask='auto')
        except Exception:
            pass
    c.setFont("Helvetica-Bold", 16)
    c.drawString(220, h - 42, get_setting("company_name"))
    c.setFont("Helvetica", 10)
    c.drawString(220, h - 58, get_setting("company_address"))
    c.drawString(220, h - 72, f"Telefon: {get_setting('company_phone')}")
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(w - 40, h - 42, number)
    c.line(40, h - 102, w - 40, h - 102)
    return w, h


def draw_label_value(c, x_label, x_value, y, label, value, width_chars=60):
    c.setFont("Helvetica-Bold", 9)
    c.drawString(x_label, y, str(label))
    c.setFont("Helvetica", 9)
    lines = wrap_text("-" if value in (None, "") else str(value), width_chars)
    yy = y
    for line in lines:
        c.drawString(x_value, yy, line)
        yy -= 12
    return yy


def section_title(c, x, y, title):
    c.setFillColorRGB(0.12, 0.12, 0.12)
    c.rect(x, y-12, 515, 18, fill=1, stroke=0)
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 10)
    c.drawString(x+6, y-1, title)
    c.setFillColorRGB(0, 0, 0)
    return y - 24


def money(v):
    try:
        return f"{float(v):.2f} €"
    except Exception:
        return str(v)

@app.route("/contracts/<int:booking_id>/pdf")
@login_required
def contract_pdf(booking_id):
    row = get_db().execute("SELECT id FROM bookings WHERE id=?", (booking_id,)).fetchone()
    if not row:
        return "Nicht gefunden", 404

    original_pdf = os.path.join(BASE_DIR, "contracts", "mietvertrag.pdf")
    if not os.path.exists(original_pdf):
        return "Originalvertrag nicht gefunden: contracts/mietvertrag.pdf", 500

    return send_file(original_pdf, mimetype="application/pdf", as_attachment=False)

@app.route("/invoices/<int:booking_id>/pdf")
@login_required
def invoice_pdf(booking_id):
    row = get_db().execute("""
        SELECT b.*,
               v.name AS vehicle_name, v.plate, v.daily_price, v.four_day_price, v.weekend_price, v.monthly_price,
               v.deposit_short, v.deposit_month, v.km_day, v.km_offer, v.km_month,
               c.first_name || ' ' || c.last_name AS customer_name, c.phone, c.email, c.address, c.license_no
        FROM bookings b
        JOIN vehicles v ON v.id=b.vehicle_id
        JOIN customers c ON c.id=b.customer_id
        WHERE b.id=?
    """, (booking_id,)).fetchone()
    if not row:
        return "Nicht gefunden", 404

    calc = calculate_price(row)
    number = invoice_no(booking_id)
    pdf_buf = io.BytesIO()
    c = canvas.Canvas(pdf_buf, pagesize=A4)

    # Header without duplicated number
    w, h = pdf_header(c, "")

    # headline area
    c.setFont("Helvetica-Bold", 18)
    c.drawString(40, h - 126, "RECHNUNG")

    c.setStrokeColorRGB(0.78, 0.64, 0.15)
    c.setLineWidth(1.2)
    c.line(40, h - 136, w - 40, h - 136)

    c.setFont("Helvetica-Bold", 11)
    c.drawString(40, h - 158, f"Rechnungsnummer: {number}")
    c.drawString(320, h - 158, f"Buchungsnummer: {contract_no(booking_id)}")

    y = h - 195

    def line(label, value, bold=False):
        nonlocal y
        c.setFont("Helvetica-Bold", 10)
        c.drawString(40, y, label)
        c.setFont("Helvetica-Bold" if bold else "Helvetica", 10)
        c.drawString(210, y, str(value) if value not in (None, "") else "-")
        y -= 20

    # Kunde / Leistung
    c.setFont("Helvetica-Bold", 11)
    c.drawString(40, y, "KUNDENDATEN")
    y -= 22
    line("Kunde", row["customer_name"])
    line("Telefon", row["phone"])
    line("E-Mail", row["email"])
    line("Fahrzeug", f"{row['vehicle_name']} / {row['plate']}")
    line("Zeitraum", f"{row['start_date']} bis {row['end_date']}")
    line("Tarif", calc["tariff"])

    y -= 6
    c.line(40, y, w - 40, y)
    y -= 24

    c.setFont("Helvetica-Bold", 11)
    c.drawString(40, y, "RECHNUNGSPOSITIONEN")
    y -= 22
    line("Mietpreis", f"{calc['rent']:.2f} €")
    line("Mehr-km", f"{calc['extra_price']:.2f} €")
    line("Kaution", "Nicht Teil der Rechnung")
    y -= 6
    c.line(40, y, w - 40, y)
    y -= 24
    line("Gesamtbetrag", f"{calc['total']:.2f} €", bold=True)

    y -= 26
    c.setFont("Helvetica", 9)
    c.drawString(40, y, "Hinweis: Die Kaution wird separat behandelt und ist nicht Teil dieser Rechnung.")
    y -= 34
    c.drawString(40, y, "Vielen Dank für Ihren Auftrag.")

    c.save()
    pdf_buf.seek(0)
    return send_file(pdf_buf, mimetype="application/pdf", as_attachment=True, download_name=f"{number}.pdf")



@app.route("/contracts/<int:booking_id>/qr")
@login_required
def contract_qr(booking_id):
    url = f"{get_setting('base_contract_url')}/{contract_no(booking_id)}.pdf"
    img = qrcode.make(url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")

if __name__ == "__main__":
    init_db()
    sync_default_vehicle_prices()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
