CCM Performance – Hosting Dateien

Schnellstart für Render oder ähnliche Python-Hoster:

1. ZIP entpacken
2. Inhalt in ein Git-Repository oder auf Render hochladen
3. Build Command:
   pip install -r requirements.txt
4. Start Command:
   gunicorn app:app

iPhone als App speichern:
1. Online-URL in Safari öffnen
2. Teilen
3. Zum Home-Bildschirm
4. Name: CCM Performance

Hinweis:
- Die SQLite-Datenbank liegt lokal in der App-Datei.
- Für dauerhaftes Hosting ist später PostgreSQL besser.
